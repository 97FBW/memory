#include <iostream>
#include <Windows.h>

using namespace std;
typedef struct node1 memory_pool_node;
typedef struct node1
{
	unsigned int colume;
	unsigned char * data;
	memory_pool_node * next;
}memory_pool_node;

typedef struct node2
{
	unsigned int totalcount;
	unsigned int used_count;
	unsigned int block_len;
	memory_pool_node *free_header;
	memory_pool_node *used_header;
}memory_pool_colum;

memory_pool_colum * bp = NULL;
unsigned int pool_num = 0;


//����ʵ��
int buffer_pool_init(unsigned int colum,unsigned int a[],unsigned int b[]);
memory_pool_node *buffer_malloc(unsigned int size);
int buffer_free(memory_pool_node * buffer);
int buffer_pool_destory(void);
int buffer_runtime_print(void);

int main()
{
	/*cout<<"preese any key to contiue ..."<<endl;
	getchar();*/
	unsigned int a[] = {1,4,8,16,32,64,128,256,512,1024,2048,5096};
	unsigned int b[] = {10000,20000,10000,1000,1000,1000,1000,500,1000,100,100,50};

	int n = sizeof(a)/sizeof(int);
	buffer_pool_init(n,a,b);
	int i = 300;
	memory_pool_node * node1 = NULL;
	memory_pool_node * node2 = NULL;
	memory_pool_node * node3 = NULL;
	memory_pool_node * node4 = NULL;
	memory_pool_node * node5 = NULL;
	memory_pool_node * node6 = NULL;
	while (i > 0)
	{
		node1 = buffer_malloc(6);
		node2 = buffer_malloc(12);
		node3 = buffer_malloc(555);
		node4 = buffer_malloc(888);
		node5 = buffer_malloc(6566);
		node6 = buffer_malloc(1);
		if (node1 != NULL)
		{
			printf("pool no[%d] get memory success!!!\n" , node1->colume);
			node1->data[0] = i;
		}
		if (node2 != NULL)
		{
			printf("pool no[%d] get memory success!!!\n" , node2->colume);
			node2->data[0] = i;
		}
		if (node3 != NULL)
		{
			printf("pool no[%d] get memory success!!!\n" , node3->colume);
			node3->data[0] = i;
		}
		if (node4 != NULL)
		{
			printf("pool no[%d] get memory success!!!\n" , node4->colume);
			node4->data[0] = i;
		}
		if (node5 != NULL)
		{
			printf("pool no[%d] get memory success!!!\n" , node5->colume);
			node5->data[0] = i;
		}

		if (node6 != NULL)
		{
			printf("pool no[%d] get memory success!!!\n" , node6->colume);
			node6->data[0] = i;
		}


		else
		{
			printf("malloc fail !!!\n");
			getchar();
		}
		i--;
		Sleep(100);
	}

	
	buffer_runtime_print();
	return 0;
}

int buffer_pool_init(unsigned int colume_no, unsigned int block_len[], unsigned int block_count[])
 {
	 
	 bp = (memory_pool_colum*)malloc(sizeof(memory_pool_colum)*colume_no);
	 memset(bp,0,sizeof(memory_pool_colum)*colume_no);
	 pool_num = colume_no;

	 memory_pool_node * curr_node  = NULL;
	 memory_pool_node * new_node = NULL;

	 for(int i = 0;i < colume_no;i++)
	 {
		 bp[i].block_len = block_len[i];
		 bp[i].totalcount = block_count[i];

		 for(int j = 0;j < block_count[i];j++)
		 {
			 new_node =(memory_pool_node *)malloc(sizeof(memory_pool_node));
			 new_node->colume = i;
			new_node->data =(unsigned char *) malloc(block_len[i]);
			memset(new_node->data , 0 ,block_len[i]);
			if (new_node == NULL || new_node->data == NULL)
				return -1;
			new_node->next = NULL;
			if (j == 0)
			{
				bp[i].free_header = new_node;
				curr_node = bp[i].free_header;
			}
			else
			{
				curr_node->next = new_node;
				curr_node = curr_node->next;
			}

		 }

	 }
	 return 0;
 }
memory_pool_node *buffer_malloc(unsigned int size)
{
	memory_pool_node * node = NULL;
	if(size > bp[pool_num-1].block_len)
	{
		printf("the new block is to big,we need need new %d from stack!\n",size);
a:		node = (memory_pool_node*)malloc(size);
		node->colume = 9999;
		node->data = (unsigned char *)malloc(size);
		memset(node->data,0,size);
		if(node == NULL || node->data == NULL)
			return NULL;
		node->next =NULL;
		return node;

	}
	for(int i = 0;i<pool_num;i++)
	{
		if(size > bp[i].block_len)
			continue;
		if(bp[i].totalcount - bp[i].used_count == 0)
		{
			printf("waring ! no :%d the memory_pool is used up!",i);
			continue;
		}
		node = bp[i].free_header;
		bp[i].free_header = bp[i].free_header->next;
		bp[i].used_count++;
		node->next = bp[i].used_header;
		bp[i].used_header = node;
		return node;
	}
	printf("warning!!!!  all of pool used up!!!! \n");
	goto a;
}

int buffer_free(memory_pool_node * buffer)
{
	memory_pool_node * node_cur = bp[buffer->colume].used_header;
	memory_pool_node * node_pre = NULL;

	if(buffer->colume == 9999)
	{
		free(buffer->data);
		free(buffer);
		buffer = NULL;
		return 0;
	}
	while(node_cur != NULL)
	{
		if(node_cur != buffer)
		{
			node_pre = node_cur;
			node_cur = node_cur->next;
			continue;
		}
		else if(node_pre == NULL)													//buff��used_header
		{
			bp[buffer->colume].used_header = bp[buffer->colume].used_header->next;
		}
		else
		{
			node_pre->next = node_cur->next;
		}
		bp[buffer->colume].used_count--;
		node_cur->next = bp[buffer->colume].free_header;
		bp[buffer->colume].free_header = node_cur;
		break;
	}
	return 0;
}

int buffer_pool_destory(void)											//�ͷ��Ѿ�ʹ�õĺ�δʹ�õ�
{
	if(bp == NULL)
		return -2;
	memory_pool_node *node_cur = NULL;
	memory_pool_node *node_del = NULL;
	for(int i = 0;i < pool_num;i++)
	{
		node_cur = bp[i].used_header;
		while(node_cur != NULL)
		{
			node_del = node_cur;
			node_cur = node_cur->next;
			free(node_del->data);
			free(node_del);
			node_del = NULL;
		}
		node_cur = bp[i].free_header;
		while(node_cur != NULL)
		{
			node_del = node_cur;
			node_cur = node_cur->next;
			free(node_del->data);
			free(node_del);
			node_del = NULL;
		}
	}
	return 0;
}

int buffer_runtime_print(void)
{
	if(bp == NULL)
	{
		printf("the memorypool not init !\n");
		return -1;
	}
	for(int i = 0;i<pool_num;i++)
	printf("pool no[%d] blocksize[%d] blockTotalCount[%d] usedBlock[%d] used percentage[%d%%]\n"
	,i , bp[i].block_len , bp[i].totalcount , bp[i].used_count , bp[i].used_count*100/ bp[i].totalcount);

	return 0;
}